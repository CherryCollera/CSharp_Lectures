﻿using AdmissionApp.Models;
using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace AdmissionApp.Helper
{
    public static class SQLiteCustomHelper
    {
        private static string databaseName = "Admission.db";
        private static async Task<bool> DoesDbExist()
        {
            bool dbexist = true;
            try
            {
                StorageFile storageFile = await ApplicationData.Current.LocalFolder.GetFileAsync(databaseName);

            }
            catch
            {
                dbexist = false;
            }

            return dbexist;
        }

        private static async Task<CreateTablesResult> CreateDatabase()
        {
            SQLiteAsyncConnection connection = new SQLiteAsyncConnection(databaseName);
            var result = await connection.CreateTableAsync<Student>();
            return result;
        }
        
        internal static async Task CheckDatabase()
        {
            if (!await Helper.SQLiteCustomHelper.DoesDbExist())
            {
                await Helper.SQLiteCustomHelper.CreateDatabase();
            }
        }

        internal static async Task<int> InsertData(Student _newStudent)
        {
            SQLiteAsyncConnection connection = new SQLiteAsyncConnection(databaseName);
            int x = await connection.InsertAsync(_newStudent);
            if (x < 0)
                return 0;
            else
                return _newStudent.Id;
        }

        internal static async Task<Student> GetDataById(string id)
        {
            SQLiteAsyncConnection connection = new SQLiteAsyncConnection(databaseName);
            return (await connection.GetAsync<Student>(id));
        }
    }
}
